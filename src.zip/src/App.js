import React from 'react'
import ReactDOM from "react-dom/client";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Navigation from './Components/Subcomponents/Navigation';
import SecondPageProducts from './Components/Subcomponents/SecondPageProducts';
import Footer from './Components/Subcomponents/Footer';
import Footer2 from './Components/Subcomponents/Footer2';
import Mainpage from './Components/Subcomponents/Mainpage';
import StyleGuidePage from './Components/Subcomponents/StyleGuidePage';
import ProductDetailPage from './Components/Subcomponents/ProductDetailPage';
import { MainpageproductsApis } from './Components/Subcomponents/MainpageproductsApis';
import FormiksForm from './Components/Subcomponents/Forms/FormiksForm';
import Login from './Components/Subcomponents/Forms/Login';
import ResetPassword from './Components/Subcomponents/Forms/ResetPassword';
import Cart from './Components/Subcomponents/Cart';
import HeaderTextCarousel from './Components/Subcomponents/HeaderTextCarousel';
import WHOWEARE from './Components/Subcomponents/LegalComponentsFolder/WHOWEARE';
import CONTACTUS from './Components/Subcomponents/LegalComponentsFolder/CONTACTUS';
import OURRESPONSIBILITIES from './Components/Subcomponents/LegalComponentsFolder/OURRESPONSIBILITIES';
import {UNSTITCHED, DUPATTAS, READYTOWEAR, SPECIALPRICES, BOTTOMS, SHAWLS} from './Components/Subcomponents/BaroqueApis'

export default function App(props) {
  return (
    <div>
      <BrowserRouter>      
            <HeaderTextCarousel />
            <Navigation />
            <Routes>
              <Route path="/" element={<Mainpage propsss={MainpageproductsApis} />} />
              <Route path="UNSTITCHED" element={<SecondPageProducts propss={UNSTITCHED} propss2={"UN-STITCHED"} />} />
              <Route path="DUPATTAS" element={<SecondPageProducts propss={DUPATTAS} propss2={"DUPATTAS"} />} />
              <Route path="READYTOWEAR" element={<SecondPageProducts propss={READYTOWEAR} propss2={"READY TO WEAR"} />} />
              <Route path="CHANTELLE" element={<SecondPageProducts propss={SPECIALPRICES} propss2={"SPECIAL PRICES"} />} />
              <Route path="BOTTOMS" element={<SecondPageProducts propss={BOTTOMS} propss2={"BOTTOMS"} />} />
              <Route path="SHAWLS" element={<SecondPageProducts propss={SHAWLS} propss2={"SHAWLS"} />} />
              <Route path="StyleGuidePage" element={<StyleGuidePage />} />
              <Route path="ProductDetailPage" element={<ProductDetailPage />} />
              <Route path="FormiksForm" element={<FormiksForm />} />
              <Route path="Login" element={<Login />} />
              <Route path="ResetPassword" element={<ResetPassword />} />
              <Route path="Cart" element={<Cart />} />
              <Route path="WHOWEARE" element={<WHOWEARE />} />
              <Route path="CONTACTUS" element={<CONTACTUS />} />
              <Route path="OURRESPONSIBILITIES" element={<OURRESPONSIBILITIES />} />
            </Routes>
            <Footer />
            <Footer2 />
        </BrowserRouter>
    </div>
  )
}
