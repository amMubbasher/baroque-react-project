import React from "react";
import { Col, Container, Row } from "react-bootstrap";
import { Link } from "react-router-dom";
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline';
import {UNSTITCHED} from './BaroqueApis'

export default function Cart(props) {
    
    // const CartApis = props.cartItems;
    const CartApis = UNSTITCHED;

    const itemPrice = CartApis.reduce((x,y) => x + y.qty * y.Price, 0);
    
    if(CartApis.length>0)
    return (
        <div className="min-h-full">
            <Container className="w-full h-full"> 
                <div className="w-full flex justify-between mt-3">
                    <div><h1>YOUR CART</h1></div>
                    <div className="pt-3"><Link to={"Collections/Unstitched"} className='text-black cursor-pointer'>Continue Shopping</Link></div>
                </div>
                <Row>
                    <Col className=" p-2">PRODUCT</Col>
                    <Col className=" p-2 d-xs-none d-none d-sm-block d-md-block  text-right ">Quantity</Col>
                    <Col className=" p-2 text-right mr-3">TOTAL</Col>
                </Row>
                <hr className="m-0 mb-2" />
                {CartApis.map((Apis) => (
                    <div className="flex mb-5">
                        <div className="  pt-0 pl-0 pr-10"><img width={150} src={Apis.src1} alt=""></img></div>
                        <Row className="w-full ml-3">
                            <Col  xs={8} sm={8} md={8} lg={8} xl={8} xxl={8} className=" p-2">
                                <Row className="w-full ">
                                    <Col xs={12} sm={6} md={6} lg={6} xl={6} className=" h-28 p-2">
                                        <Link to={'/ProductsDetailsPage'} className='no-underline text-black' state={{ name:  Apis  }}><p className="m-0 hover:underline decoration-2 cursor-pointer">{Apis.ProductTitle}</p></Link>
                                        <p className="pt-0 m-0 pb-0">PKR{' '}{Apis.Price}</p>
                                    </Col>
                                    <Col xs={12} sm={6} md={6} lg={6} xl={6} className=" p-2">
                                        <div className='ml-0 flex flex-row text-center  xs-justify-start sm:justify-end cursor-pointer mr-7'>

                                            <div className='w-7 h-7 border-2 border-black' onClick={() => props.onRemove(Apis)}>-</div>
                                            <div className='w-7 h-7 border-2 border-black ' >1</div>
                                            <div className='w-7 h-7 border-2 border-black' onClick={() => props.onAdd(Apis)}>+</div>
                                            <div className=' ml-3' onClick={() => props.onDelete(Apis)}><DeleteOutlineIcon/></div>
                                        </div>
                                    </Col>
                                </Row>
                            </Col>
                            <Col xs={4} sm={4} md={4} lg={4} xl={4} xxl={4} className=" p-2 text-right">PKR. {Apis.Price * Apis.qty}</Col>
                        </Row></div>
                )
                )}
                <hr className="mt-5" />
                <div className="grid justify-end text-end mb-5">
                    <p className="text-lg">SUBTOTAL  PKR {itemPrice}</p>
                    <p className="text-sm mb-4">Taxes and<Link to={""} className='text-black'> shipping</Link> calculated at checkout</p>
                    <div className="text-center text-white bg-black h-10 w-96 font-bold pt-2">CHECKOUT</div>
                </div>
            </Container>
            
        </div>
    );
    else
    return(
        <div className="text-center min-h-full">
        <div className="text-4xl mt-32 mb-28">YOUR CART IS EMPTY</div>
        <div className=" text-2xl mb-2">HAVE AN ACCOUNT?</div>
        <div className="text-sm"><Link to={'/LoginP'}  state={{name:"none", number:"none", sew:"none" }}className='text-black'>LOG IN </Link>  TO CHECKOUT FASTER</div>
            </div>
    );
}