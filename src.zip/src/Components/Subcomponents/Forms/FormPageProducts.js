import React, { useState } from 'react';
import Button from 'react-bootstrap/Button';
import Collapse from 'react-bootstrap/Collapse';

export default function FormPageProducts() {
  return (
    <div className="flex justify-center">
      <div className="mt-10 text-sm w-96">
        <div className="flex flex-row">
          <img
            src="https://cdn.shopify.com/s/files/1/2277/5269/products/84_09eaaf0d-bddb-46d4-9315-ea207f053057_small.jpg?v=1668248478"
            alt=""
            className="mr-3"
          />
          <div>
            <p className="font-medium">PLAIN CHIFFON FROCK SUIT PR-723</p>
            <div className="flex flex-row justify-between">
              <p className="text-xs">XS</p>
              <p className="font-medium">Rs. 14,999.00</p>
            </div>
            <p className="text-xs">Custom_Color: BLACK</p>
          </div>
        </div>
        <hr />

        <div className="flex flex-row">
          <input
            className="form-control shadow-none border-2 w-full p-2 mr-2"
            placeholder="Gift card or discount code"
            type="text"
          />
          <button className="btn btn-secondary border-2 m-0">Apply</button>
        </div>
        <hr />

        <div className="flex flex-row justify-between">
          <p className="text-sm">Subtotal</p>
          <p className="font-medium">Rs. 14,999.00</p>
        </div>
        <div className="flex flex-row justify-between">
          <p className="text-sm">Shipping</p>
          <p className="">Calculated at next step</p>
        </div>
        <hr />
        <div className="flex flex-row justify-between">
          <p className="text-base">Total</p>
          <p className="text-xl font-semibold">Rs. 14,999.00</p>
        </div>
      </div>
    </div>
  );
}
