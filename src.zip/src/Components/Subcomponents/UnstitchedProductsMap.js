import React from 'react'
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import UnstitchedSourcesthroughApis from './UnstitchedSourcesthroughApis';

export default function SecondPageRight(props) {
  return (
    <div>
        <Container>
            <Row>
                {props.props.map((UnstitchedApis) =>{
                    return(
                        <Col sm={12} md={6} lg={4} xl={4} xxl={4}>
                            <UnstitchedSourcesthroughApis UnstitchedApisData={UnstitchedApis} />
                        </Col>
                    )
                })}
        </Row>
        </Container>
    </div>
  )
}
