import React, { useState } from "react";
import { Outlet, Link } from "react-router-dom";

export default function SecondHoverPage(props) {
  const [Image, setImage] = useState(props.UnstitchedApisData.src1);
  const [NavNumber, setNavNumber] = useState(props.navnumber);
  const prop = props.UnstitchedApisData;

  return (
    <div className="flex flex-col justify-center items-center no-underline">
      <Link to="/ProductDetailPage" state={{data:prop}}>
        <img
          className="cursor-pointer"
          src={Image}
          alt=""
          onMouseEnter={() => {
            setImage(prop.src2);
          }}
          onMouseLeave={() => {
            setImage(prop.src1);
          }}
        />
      </Link>
      <p className="mt-3">{prop.ProductTitle}</p>
      <Link to="/ProductDetailPage" className="no-underline">
        <p className="font-bold cursor-pointer text-black hover:underline">
          PKR. {prop.ProductPrice}
        </p>
      </Link>
    </div>
  );
}
