import React from 'react'

export default function Footer2() {
  return (
    <div>
      <div className="text-center text-sm bg-black pt-3 pb-3 text-white">
            ALL RIGHTS RESERVED by <a className='underline cursor-pointer text-gray-300 text-sm' href="https://mubbasher-yasin.github.io/Resume-Website/" target={"_blank"}>Mubbasher Yasin</a>. Click <a className='underline cursor-pointer text-gray-300' href="https://mubbasher-yasin.github.io/Resume-Website/" target={"_blank"}>Here</a> to contact
      </div>
    </div>
  )
}
